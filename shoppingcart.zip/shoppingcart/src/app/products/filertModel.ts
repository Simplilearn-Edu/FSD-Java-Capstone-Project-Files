export class FilterModal {
    constructor(
        public sort: string,
        public category: string
    ) {}
}
